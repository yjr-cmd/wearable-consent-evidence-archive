# Archive manifest

This archive contains the source-matched document set for final cases AG1-AG18, together with the supporting third-party/SDK materials supplied for the current revision. Supporting attachments supplement, but do not replace, the primary policy documents used for coding.

## Directory structure

- `01_markdown_texts/`: 19 searchable text copies covering AG1-AG18. AG12 contains two files because its product-specific policy is read together with an expressly incorporated general privacy statement.
- `02_original_policy_files/`: 19 controlling original snapshots corresponding to the Markdown texts.
- `03_supporting_attachments/01_original_files/`: 11 controlling supporting attachments for AG1, AG2, AG3, AG9, AG10 and AG13.
- `03_supporting_attachments/02_markdown_texts/`: 11 searchable text-access copies of those attachments.
- `03_supporting_attachments/ATTACHMENT_MANIFEST.md`: case-by-case mapping of supplied names, normalized filenames and material types.

## Primary Markdown texts

- `AG01_Huawei_privacy_policy.md`
- `AG02_Xiaomi_privacy_policy.md`
- `AG03_OPPO_privacy_policy.md`
- `AG04_vivo_privacy_policy.md`
- `AG05_Honor_privacy_policy.md`
- `AG06_Amazfit_privacy_policy.md`
- `AG07_Keep_privacy_policy.md`
- `AG08_RingConn_privacy_policy.md`
- `AG09_Dreame_privacy_policy.md`
- `AG10_Meizu_MYVU_privacy_policy.md`
- `AG11_Black_Shark_privacy_policy.md`
- `AG12_Lenovo_General_Privacy_Statement_supplement.md`
- `AG12_Lenovo_Health_Life_privacy_policy.md`
- `AG13_Baidu_Xiaodu_privacy_policy.md`
- `AG14_Huawei_Audio_privacy_policy.md`
- `AG15_Edifier_privacy_policy.md`
- `AG16_Shokzhear_privacy_policy.md`
- `AG17_QCY_privacy_policy.md`
- `AG18_Earweiss_privacy_policy.md`

## Primary original snapshots

- `AG01_Huawei_source_document.docx`
- `AG02_Xiaomi_source_document.docx`
- `AG03_OPPO_source_document.pdf`
- `AG04_vivo_source_document.docx`
- `AG05_Honor_source_document.docx`
- `AG06_Amazfit_source_document.docx`
- `AG07_Keep_source_document.pdf`
- `AG08_RingConn_source_document.docx`
- `AG09_Dreame_source_document.docx`
- `AG10_Meizu_MYVU_source_document.pdf`
- `AG11_Black_Shark_source_document.docx`
- `AG12_Lenovo_General_Privacy_Statement_supplement.docx`
- `AG12_Lenovo_Health_Life_source_document.pdf`
- `AG13_Baidu_Xiaodu_source_document.md`
- `AG14_Huawei_Audio_source_document.docx`
- `AG15_Edifier_source_document.docx`
- `AG16_Shokzhear_source_document.docx`
- `AG17_QCY_source_document.docx`
- `AG18_Earweiss_source_document.docx`

## Case-specific provenance and limitations

- **AG12:** Supplementary source matching closed on 25 September 2026. The product-specific Lenovo Health Life policy was archived on 27 September 2026 and is read together with the incorporated Lenovo general privacy statement accessed on 5 August 2026.
- **AG05 (Honor):** The primary policy refers to an Honor Health personal-information sharing list, but no separately accessible copy was supplied or archived. Coding remains based on the primary policy text.
- **AG07 (Keep):** Relevant third-party/SDK disclosures are contained within the primary archived policy. No separate attachment was supplied or archived.
- **AG01 (Huawei):** A third-party information-sharing list is archived, but the preserved PDF ends part-way through the Apple HealthKit entry and its second page is blank. It must not be described as a complete copy of the list.
- Supporting attachments were supplied from the authors' revision working set. Unless a retrieval URL or date is documented elsewhere in the case records or the file itself, this archive does not infer one. The attachments do not alter the already fixed coding merely by being present.
