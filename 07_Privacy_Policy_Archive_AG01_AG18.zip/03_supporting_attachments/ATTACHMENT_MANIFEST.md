# Supporting Attachments Manifest

This directory contains supporting lists, statements, and SDK/third-party disclosures collected for the current revision. These files supplement, but do not replace, the 18 primary policy document sets used for coding.

## Directory structure

- `01_original_files/`: unchanged copies of the supplied PDF/DOCX files, renamed consistently by case.
- `02_markdown_texts/`: searchable text-access copies generated from the originals.
- The original PDF/DOCX remains the controlling archived source if pagination or layout matters.

## File mapping

| Case | Brand | Original supplied path | Normalized original | Markdown text | Material type |
| --- | --- | --- | --- | --- | --- |
| AG01 | Huawei | AG附件/华为/关于华为账号与隐私的声明.pdf | `01_original_files/AG01_Huawei_Account_Privacy_Statement.pdf` | `02_markdown_texts/AG01_Huawei_Account_Privacy_Statement.md` | Account privacy statement (1 PDF page(s)) |
| AG01 | Huawei | AG附件/华为/华为运动健康 App 隐私声明摘要.pdf | `01_original_files/AG01_Huawei_Health_App_Privacy_Summary.pdf` | `02_markdown_texts/AG01_Huawei_Health_App_Privacy_Summary.md` | Privacy statement summary (2 PDF page(s)) |
| AG01 | Huawei | AG附件/华为/关于运动健康数据同步服务与隐私的声明.pdf | `01_original_files/AG01_Huawei_Health_Data_Synchronization_Privacy_Statement.pdf` | `02_markdown_texts/AG01_Huawei_Health_Data_Synchronization_Privacy_Statement.md` | Data synchronization service privacy statement (2 PDF page(s)) |
| AG01 | Huawei | AG附件/华为/关于华为运动健康与隐私的声明.pdf | `01_original_files/AG01_Huawei_Health_Privacy_Statement.pdf` | `02_markdown_texts/AG01_Huawei_Health_Privacy_Statement.md` | Huawei Health privacy statement (15 PDF page(s)) |
| AG01 | Huawei | AG附件/华为/第三方共享信息清单.pdf | `01_original_files/AG01_Huawei_Third_Party_Information_Sharing_List.pdf` | `02_markdown_texts/AG01_Huawei_Third_Party_Information_Sharing_List.md` | Third-party information sharing list (2 PDF page(s)) |
| AG02 | Xiaomi | AG附件/小米/‎小米.pdf | `01_original_files/AG02_Xiaomi_Third_Party_Information_Sharing_List.pdf` | `02_markdown_texts/AG02_Xiaomi_Third_Party_Information_Sharing_List.md` | Third-party information sharing list (7 PDF page(s)) |
| AG03 | OPPO | AG附件/oppo/oppo.pdf | `01_original_files/AG03_OPPO_Third_Party_Information_Sharing_List.pdf` | `02_markdown_texts/AG03_OPPO_Third_Party_Information_Sharing_List.md` | Third-party information sharing list (81 PDF page(s)) |
| AG09 | Dreame | AG附件/dreamme/DreameHealth.pdf | `01_original_files/AG09_Dreame_Third_Party_SDK_List.pdf` | `02_markdown_texts/AG09_Dreame_Third_Party_SDK_List.md` | Third-party SDK information/list (8 PDF page(s)) |
| AG10 | Meizu (MYVU) | AG附件/魅族/个人信息收集清单.pdf | `01_original_files/AG10_Meizu_Personal_Information_Collection_List.pdf` | `02_markdown_texts/AG10_Meizu_Personal_Information_Collection_List.md` | Personal information collection list (9 PDF page(s)) |
| AG10 | Meizu (MYVU) | AG附件/魅族/第三方信息共享清单.pdf | `01_original_files/AG10_Meizu_Third_Party_Information_Sharing_List.pdf` | `02_markdown_texts/AG10_Meizu_Third_Party_Information_Sharing_List.md` | Third-party information sharing list (5 PDF page(s)) |
| AG13 | Baidu (Xiaodu) | AG附件/小度/小度APP与第三方共享个人信息清单.docx | `01_original_files/AG13_Baidu_Xiaodu_Third_Party_Information_Sharing_List.docx` | `02_markdown_texts/AG13_Baidu_Xiaodu_Third_Party_Information_Sharing_List.md` | Third-party personal information sharing list (3 DOCX table(s)) |

## Cases without a separate attachment

- **AG05 (Honor):** No separately accessible third-party list or other attachment was supplied. Coding should therefore remain based on the archived primary policy text; no placeholder attachment has been created.
- **AG07 (Keep):** No separately accessible third-party list or other attachment was supplied. Coding should therefore remain based on the archived primary policy text; no placeholder attachment has been created.

## Scope note

The attachment set documents what the archived materials state. It should not be used, by itself, to infer undisclosed processing or actual platform practice. Any citation in the Evidence Matrix should identify the specific case and supporting file used.

These attachments were supplied from the authors' revision working set. A separate retrieval URL and retrieval date were not independently recorded in the supplied attachment set unless documented elsewhere in the case records or visible in the controlling file. No missing provenance has been inferred.

The archived AG01 Huawei third-party information-sharing list is incomplete as preserved: page 1 ends part-way through the Apple HealthKit entry and page 2 is blank. It supports verification of the entries visibly present but must not be treated as a complete copy of the list.
