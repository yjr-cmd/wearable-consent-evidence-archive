# OPPO Third-Party Information Sharing List

- Case: AG03
- Brand: OPPO
- Material type: Third-party information sharing list
- Original filename: `oppo.pdf`
- Original format: PDF
- Archive role: Supporting attachment for documentary verification of third-party sharing and SDK disclosures.

> Note: This Markdown file is a text-access copy generated from the archived original. The original file remains the controlling archived source.

## Page 1

2026/9/29 17:42
第三方信息共享清单
一、第三方 SDK 列表
S
D
K
高德开放平台定位SDK
名
称
所
属
安卓
系
统
第
三
方
公
高德软件有限公司
司
https://sport.health.heytapmobi.com/h5/statement/index.html#/?new...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第1/81⻚

## Page 2

2026/9/29 17:42
名
称
第
三 OPPO 健康处于前台或后台运行状态时,该SDK会获取以下个
方 人信息: 位置信息:经纬度、精确位置、粗略位置;设备信息
收 【IP 地址、GNSS信息、网络类型、WiFi状态、WiFi参数、Wi
集 Fi列表、SSID、BSSID、基站信息、WiFi信号强度的信息、蓝
的 牙信息、传感器信息(矢量、加速度、压力)、设备信号强度
个 信息、外部存储目录】、设备标识信息(IDFA、OAID)、当
人 前应用信息(应用名、应用版本号)、设备参数及系统信息(
信 系统属性、设备型号、操作系统、运营商信息、屏幕分辨率)
息
我
们
从
第
三
方
获
粗略位置
取
https://sport.health.heytapmobi.com/h5/statement/index.html#/?new...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第2/81⻚

## Page 3

2026/9/29 17:42
的
个
人
信
息
第
三
方
可
能
位置、后台定位、存储
调
用
的
权
限
实
现
功 OPPO 健康中使用到定位和地图能力的功能,如区域步数排行
能
榜、包含轨迹的运动功能、查找设备、设备钱包
https://sport.health.heytapmobi.com/h5/statement/index.html#/?new...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第3/81⻚

## Page 4

2026/9/29 17:42
/
场
景
(1)位置信息:为了给应用返回用户位置信息,并供开发者
基于用户的位置信息提供相应服务;为了便于提供实时路况和
处 路况预测服务,我们会对用户的位置信息进行数据统计和分
理 析,并基于此对交通拥堵状况作判断;(2)设备信息:为了
目 帮助开发者向用户提供定位、辅助定位,实现给开发者提供最
的 终用户更精准的位置信息;(3)设备标识信息:为了提供定
位服务准确性和成功率,追踪、排查、诊断、统计服务中的各
类问题,保障产品和服务安全正常运行
处
理
SDK 采集
方
式
联
系
官网: https://lbs.amap.com/
方
式
https://sport.health.heytapmobi.com/h5/statement/index.html#/?new...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第4/81⻚

## Page 5

2026/9/29 17:42
第
三
方
隐
私 https://lbs.amap.com/pages/privacy/
政
策
链
接
S
D
K
高德开放平台地图SDK
名
称
所
属
安卓
系
统
https://sport.health.heytapmobi.com/h5/statement/index.html#/?new...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第5/81⻚

## Page 6

2026/9/29 17:42
第
三
方
高德软件有限公司
公
司
名
称
第
OPPO 健康处于前台或后台运行状态时,该SDK会获取以下个
三
人信息: 位置信息:经纬度、精确位置、粗略位置;设备信息
方
【IP 地址、GNSS信息、网络类型、WiFi状态、WiFi参数、Wi
收
Fi列表、SSID、BSSID、基站信息、WiFi信号强度的信息、蓝
集
牙信息、传感器信息(矢量、加速度、压力、方向、地磁)、
的
设备信号强度信息、外部存储目录】、设备标识信息(IDFA、
个
OAID)、当前应用信息(应用名、应用版本号)、设备参数
人
及系统信息(系统属性、设备型号、操作系统、运营商信息、
信
屏幕分辨率)
息
我
们
从
https://sport.health.heytapmobi.com/h5/statement/index.html#/?new...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第6/81⻚

## Page 7

2026/9/29 17:42
第
三
方
粗略位置
获
取
的
个
人
信
息
第
三
方
可
能
位置、后台定位、存储
调
用
的
权
限
https://sport.health.heytapmobi.com/h5/statement/index.html#/?new...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第7/81⻚

## Page 8

2026/9/29 17:42
实
现
功
OPPO 健康中使用到地图能力的功能,如区轨迹的运动功能
能
/
场
景
(1)位置信息:为了给应用返回用户位置信息,并供开发者
基于用户的位置信息提供相应服务;为了便于提供实时路况和
处 路况预测服务,我们会对用户的位置信息进行数据统计和分
理 析,并基于此对交通拥堵状况作判断;(2)设备信息:为了
目 帮助开发者向用户提供定位、辅助定位,实现给开发者提供最
的 终用户更精准的位置信息;(3)设备标识信息:为了提供定
位服务准确性和成功率,追踪、排查、诊断、统计服务中的各
类问题,保障产品和服务安全正常运行
处
理
SDK 采集
方
式
https://sport.health.heytapmobi.com/h5/statement/index.html#/?new...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第8/81⻚

## Page 9

2026/9/29 17:42
联
系 官网: https://lbs.amap.com/
方
式
第
三
方
隐
私 https://lbs.amap.com/pages/privacy/
政
策
链
接
SDK 名
App 支付宝客户端 SDK
称
所属系
安卓
统
https://sport.health.heytapmobi.com/h5/statement/index.html#/?new...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第9/81⻚

## Page 10

2026/9/29 17:42
第三方
支付宝支付科技有限公司
公司名
称
第三方
AndroidID、传感器信息(传感器列表)、设备屏幕密
收集的
度、运营商信息、WIFI参数、网络类型、OAID、ip地
个人信
址、支付宝APP安装状态。
息
我们从
第三方
获取的 无
个人信
息
第三方
可能调
网络连接权限、设备状态权限
用的权
限
实现功
为用户提供支付服务,绑定支付宝运动。
能/场景
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第10/81⻚

## Page 11

2026/9/29 17:42
1、保障用户账户和资金安全以及支付服务的安全稳定运
处理目
行。2、履行反洗钱、反恐怖融资、反电信网络诈骗等法
的
定义务。3、实现网络链路的选择和优化,以提升用户体
验。
处理方
SDK 采集
式
联系方
4007585858
式
第三方
https://render.alipay.com/p/yuyan/180020010001196791/pre
隐私政
view.html?agreementId=AG00000132
策链接
SDK 名称 Glide SDK
所属系统 安卓
第三方公司
个人开发者
名称
第三方收集
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第11/81⻚

## Page 12

2026/9/29 17:42
的个人信息 无
我们从第三
方获取的个 无
人信息
第三方可能
访问共享存储空间的媒体文件
调用的权限
实现功能/场
OPPO 健康 App 中涉及图片加载的功能
景
处理目的 优化图片加载的体验
处理方式 不涉及
email https://groups.google.com/forum/#!forum/glidelib
联系方式 raryIRC channel: http://webchat.freenode.net/?channels
=glide-library
第三方隐私
bumptech/glide
政策链接
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第12/81⻚

## Page 13

2026/9/29 17:42
Yalantis SDK
SDK 名称
所属系统 安卓
第三方公司名称 乌克兰亚兰蒂斯软件公司
第三方收集的个人
无
信息
我们从第三方获取
无
的个人信息
第三方可能调用的
读取外置存储卡、写入外部存储卡
权限
对用户选中的图片进行裁切处理,用于相册表
实现功能/场景
盘
处理目的 相册表盘裁切功能
处理方式 SDK 采集
联系方式 官网 https://yalantis.com/company/#about
第三方隐私政策链 https://docs.github.com/en/site-policy/privacy-poli
cies/github-privacy-statement
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第13/81⻚

## Page 14

2026/9/29 17:42
cies/github-privacy-statement
接
SDK 名称 com.tencent.mmkv
所属系统 安卓
第三方公司名称 深圳市腾讯计算机系统有限公司
第三方收集的个
正在运行的应用程序
人信息
我们从第三方获
无
取的个人信息
第三方可能调用
无
的权限
实现功能/场景 应用多进程数据缓存
处理目的 提升应用运行性能
处理方式 SDK 采集
联系方式
https://kf.qq.com/
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第14/81⻚

## Page 15

2026/9/29 17:42
第三方隐私政策 https://support.weixin.qq.com/cgi-bin/mmsupportacc
tnodeweb-bin/pages/aY5BAtRiO1BpoHxo
链接
SDK 名称 微信Open SDK
所属系统 安卓
第三方公司名称 深圳市腾讯计算机系统有限公司
第三方收集的个 步数,穿戴设备名称、运动记录、应用安装信
人信息 息、应用信息( OPPO 健康版本信息)
我们从第三方获
无
取的个人信息
第三方可能调用
无
的权限
实现功能/场景 1、微信运动排行榜展示2、实现微信分享功能
1、微信运动排行榜展示,用户更好的体验2、实
处理目的
现微信分享功能
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第15/81⻚

## Page 16

2026/9/29 17:42
处理方式 SDK 采集
联系方式 官网:https://kf.qq.com/
第三方隐私政策 https://support.weixin.qq.com/cgi-bin/mmsupportacc
tnodeweb-bin/pages/RYiYJkLOrQwu0nb8
链接
SD
K
商城SDK
名
称
所
属
安卓
系
统
第
三
方
公
东莞市永盛通信科技有限公司
司
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第16/81⻚

## Page 17

2026/9/29 17:42
名
称
第
三
方 网络身份识别信息、IMEI(用户主动输入)、手机号、收货
收 地址、姓名、邮箱、银行账号、支付宝账号、位置信息商城
集 SDK可能还会和其他服务商(例如神策SDK)一起为你提供服
的 务,但我们没有直接集成这些服务商的SDK,您可以查阅商
个 城SDK的个人信息保护政策了解更多关于这些服务商对您个
人 人信息的处理。
信
息
我
们
从
第
三
方
获
无
取
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第17/81⻚

## Page 18

2026/9/29 17:42
的
个
人
信
息
第
三
方
可
能 1、读取外置存储器(安卓13系统以下)2、写入外置存储器
调 (安卓13系统以下)3、摄像头4、位置权限
用
的
权
限
实
现
功
能/ 提供电商服务
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第18/81⻚

## Page 19

2026/9/29 17:42
场
景
处
理
提供电商服务
目
的
处
理
SDK 采集
方
式
联
系
官网:https://www.opposhop.cn/cn/m/
方
式
第
三
方
隐
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第19/81⻚

## Page 20

2026/9/29 17:42
https://www.opposhop.cn/legal/privacy/storesdk-privacy-policies.
私
html
政
策
链
接
SDK
Bugly
名称
所属
安卓
系统
第三
方公
深圳市腾讯计算机系统有限公司
司名
称
第三 手机型号、手机品牌、Android系统版本、Android系统api等
方收 级、厂商系统版本、cpu架构类型、设备是否root、磁盘空
集的 间占用大小、sdcard空间占用大小、内存空间占用大小、网
个人 络类型、应用当前正在运行的进程名和PID、deviceId、 OP
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第20/81⻚

## Page 21

2026/9/29 17:42
信息 PO 健康应用包名信息
我们
从第
三方
获取 无
的个
人信
息
第三
方可
能调 1、获取网络2、获取网络连接
用的
权限
实现
功能/ 上报应用异常信息
场景
处理 分析三方手机的crash信息,在三方手机提供更稳定可靠的
目的 使用体验
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第21/81⻚

## Page 22

2026/9/29 17:42
处理 SDK 采集
方式
联系
官网:https://bugly.qq.com/
方式
第三
方隐
https://privacy.qq.com/document/preview/fc748b3d96224fdb82
私政
5ea79e132c1a56
策链
接
SDK 名称 Google二维码识别 SDK
所属系统 安卓
第三方公司名称 谷歌公司
第三方收集的个人信息 应用信息( OPPO 健康版本信息)
我们从第三方获取的个人信
无
息
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第22/81⻚

## Page 23

2026/9/29 17:42
第三方可能调用的权限 无
实现功能/场景 提供二维码识别能力
处理目的 为了准确识别二维码
处理方式 本地处理
https://developers.google.com/ml-kit/gui
联系方式
des
https://developers.google.com/ml-kit/ter
第三方隐私政策链接
ms
SDK
小米推送SDK
名称
所属
安卓
系统
第三
方公
北京小米移动软件有限公司
司名
称
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第23/81⻚

## Page 24

2026/9/29 17:42
第三 设备标识OAID、加密的Android ID、应用包名、版本号和
方收 运行状态、设备厂商、设备型号、设备内存、操作系统版
集的 本、小米推送SDK版本、设备归属地(国家或地区)、SIM
个人 卡运营商名称、当前网络类型、WiFi状态、通知栏设置信
信息 息、消息创建、送达和点击时间
我们
从第
三方
获取 无
的个
人信
息
第三
方可
能调 无
用的
权限
实现
功能/ 提供推送服务
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第24/81⻚

## Page 25

2026/9/29 17:42
场景
处理
推送消息到小米设备终端
目的
处理
SDK 采集
方式
联系
https://privacy.mi.com/support
方式
第三
方隐
私政 https://dev.mi.com/distribute/doc/details?pId=1534
策链
接
SDK 名称 华为推送SDK
所属系统 安卓
第三方公司
华为软件技术有限公司
名称
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第25/81⻚

## Page 26

2026/9/29 17:42
第三方收集 应用信息、设备信息(设备的硬件信息、系统基本
的个人信息 信息和系统设置)
我们从第三
方获取的个 无
人信息
第三方可能
获取网络状态权限、访问网络权限
调用的权限
实现功能/场
提供推送服务
景
1、提供消息推送服务;2、统计华为推送SDK接又
处理目的
调用成功率。
处理方式 SDK 采集
https://developer.huawei.com/consumer/cn/support/cont
联系方式
actUs
https://developer.huawei.com/consumer/cn/doc/develop
第三方隐私
ment/HMSCore-Guides/sdk-data-security-0000001050
政策链接 042177
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第26/81⻚

## Page 27

2026/9/29 17:42
SDK 名称 vivo推送SDK
所属系统 安卓
第三方公司名
维沃移动通讯有限公司
称
appid,appkey,应用包名,应用版本号,pushSDK
第三方收集的
版本、vpush的regId、设备类型、系统类型、系统
个人信息
版本
我们从第三方
获取的个人信 无
息
第三方可能调
无
用的权限
实现功能/场
提供推送服务
景
处理目的 推送消息到vivo设备终端
处理方式 SDK 采集
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第27/81⻚

## Page 28

2026/9/29 17:42
https://www.vivo.com
联系方式
第三方隐私政
https://dev.vivo.com.cn/documentCenter/doc/706#
策链接
SDK 名称 OPUSH SDK
所属系统 安卓
第三方公司
广东欢太科技有限公司
名称
应用基本信息(MCS应用包名、应用版本号、OPUS
第三方收集
H SDK版本号),应用内设备标识符(RegistraterI
的个人信息
D、appKey、appSecret)
我们从第三
方获取的个 无
人信息
第三方可能
无
调用的权限
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第28/81⻚

## Page 29

2026/9/29 17:42
实现功能/ 提供推送服务
场景
处理目的 推送消息到设备终端
处理方式 SDK采集
联系方式 https://brand.heytap.com/privacy-feedback.html
第三方隐私 https://open.oppomobile.com/new/developmentDoc/info?
id=11228
政策链接
SDK 名
荣耀推送SDK
称
所属系
安卓
统
第三方
公司名 深圳荣耀软件技术有限公司或关联公司
称
第三方
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第29/81⻚

## Page 30

2026/9/29 17:42
收集的 设备标识符(AAID、PushToken)
个人信
息
我们从
第三方
获取的 无
个人信
息
第三方
可能调
无
用的权
限
实现功
提供推送服务
能/场景
处理目
向用户推送通知消息
的
处理方
SDK采集
式
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第30/81⻚

## Page 31

2026/9/29 17:42
联系方
https://brand.heytap.com/privacy-feedback.html
式
https://developer.hihonor.com/cn/kitdoc?category=%E5%9
第三方
F%BA%E7%A1%80%E6%9C%8D%E5%8A%A1&kitId=1
隐私政
1002&navigation=guides&docId=sdk-data-security.md&tok
策链接
en=
SDK 名
乐心SDK
称
所属系统 安卓
第三方公
深圳市乐心医疗电子有限公司
司名称
第三方收
集的个人 无
信息
我们从第
设备序列号、体重、体脂率、阻抗、心率、肌肉量、身
三方获取
体年龄、脂肪量、内脏脂肪等级、基础代谢量、去脂体
的个人信
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第31/81⻚

## Page 32

2026/9/29 17:42
息 重、肌肉率、水分率、骨量、蛋白质、骨骼肌、BMI
第三方可
能调用的 无
权限
实现功
绑定体质秤时
能/场景
处理目的 用于绑定体脂秤,得到原始体重信息
处理方式 乐心SDK、云端API传输
联系方式 http://www.lifesense.com
第三方隐
私政策链 https://docs.sghealth.cn/FAQ/privacy.html
接
SDK 名称 抖音open SDK
所属系统 安卓
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第32/81⻚

## Page 33

2026/9/29 17:42
第三方公司
北京微播视界科技有限公司
名称
第三方收集 头像、昵称、手机号、操作系统、user agent、分享
的个人信息 记录(图片、视频内容)
我们从第三
方获取的个 无
人信息
第三方可能
无
调用的权限
实现功能/场
实现抖音分享功能
景
处理目的 实现抖音分享功能
处理方式 SDK采集
联系方式 https://developer.open-douyin.com/docs-page
https://developer.open-douyin.com/docs/resource/zh-CN/
第三方隐私
dop/operation-standard/service-protocol/douyinsdk_ping
政策链接
taiyinsizhengce
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第33/81⻚

## Page 34

2026/9/29 17:42
SDK 名称 QQ互联 SDK
所属系统 安卓
第三方公司
深圳市腾讯计算机系统有限公司
名称
第三方收集
操作系统信息、ssid/bssid、设备型号、应用列表信息
的个人信息
我们从第三
方获取的个 无
人信息
第三方可能
相册、内存卡权限
调用的权限
实现功能/
实现QQ分享功能
场景
处理目的 实现QQ分享功能
处理方式 SDK采集
联系方式 https://connect.qq.com/
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第34/81⻚

## Page 35

2026/9/29 17:42
https://wiki.connect.qq.com/qq%e4%ba%92%e8%81%94
第三方隐私
sdk%e9%9a%90%e7%a7%81%e4%bf%9d%e6%8a%a
政策链接
4%e5%a3%b0%e6%98%8e
SDK 名称 小红书Open SDK
所属系统 安卓
第三方公司名称 行吟信息科技(上海)有限公司
第三方收集的个人 设备信息(Android ID/IDFA/操作系统、系统
信息 版本、设备型号)
我们从第三方获取
无
的个人信息
第三方可能调用的
相册、内存卡权限
权限
实现功能/场景 实现小红书分享功能
处理目的 实现小红书分享功能
处理方式 SDK采集
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第35/81⻚

## Page 36

2026/9/29 17:42
联系方式 邮箱:ft_agora@xiaohongshu.com
第三方隐私政策链 https://agree.xiaohongshu.com/h5/terms/ZXXY20
230525001/-1?source=agora
接
SDK 名称 Glyphix SDK
所属系统 安卓
第三方公司
上海聚谌智能科技有限公司
名称
第三方收集 健康处于前台或后台运行状态时,该SDK不会收集
的个人信息 个人数据
我们从第三
方获取的个 无
人信息
第三方可能
网络,网络变化,weak_lock
调用的权限
实现功能/场
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第36/81⻚

## Page 37

2026/9/29 17:42
景 分享手机网络给到 Glyphix 手表快应用
- 网络权限(手表网络分享)- 监听网络状态(通知
处理目的 手表连接改变)- weak_lock 防止系统休眠(防止断
网)
处理方式 SDK 采集
联系方式 support@xfaith-tech.com
第三方隐私
https://www.glyphix.app/sdk_privacy.html
政策链接
以下这些SDK属于由我们自主开发的SDK:
名称 目的
com.heytap.ups 提供通知推送服务
com.platform.use
提供账号服务
rcenter
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第37/81⻚

## Page 38

2026/9/29 17:42
com.oplus.log
用于帮助与反馈功能。处理问题反馈时,提取错
误日志以分析问题
com.oplus.shield 用于兼容ColorOS API,提升应用运行稳定性
有 关 我 们 自 主 开 发 的 SDK 如 何 收 集 和 处 理 您 的 个 人 信
息,请见 OPPO 健康个人信息保护政策“我们如何收集
和处理您的个人信息”一章。
二、其他第三方信息共享列表
(1)服务类型:健康改善服务
浙江好络维医疗技术有限公司(好络维,仅在
第三方公司名称
心电部分版本中提供服务)
我们分享的个人信
身高、体重、年龄
息
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第38/81⻚

## Page 39

2026/9/29 17:42
我们从第三方获取
心电分析结果和专家解读报告
的个人信息
第三方可能调用的
无
权限
实现功能/场景 为用户提供心电分析和解读服务
处理目的 为用户提供心电分析和解读服务
处理方式 云端接又传输
联系方式 http://www.hellowin.cn
第三方隐私政策链 https://api.995120.cn/static/hm503/single/ecgplus/
privacy-plus.html
接
第三方公司名
欧姆龙健康医疗(中国)有限公司
称
产品/类型 血压计
我们分享的个
无
人信息
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第39/81⻚

## Page 40

2026/9/29 17:42
我们从第三方 血压数据、设备蓝牙MAC地址、设备SN、收缩
获取的个人信 压、舒张压、脉冲、心律失常、测量用户、测量时
息 间
第三方可能调
无
用的权限
实现功能/场景 向用户展示血压相关的数据指标
处理目的 向用户展示血压相关的数据指标
处理方式 蓝牙传输
联系方式 https://www.omronhealthcare.com.cn/
第三方隐私政
https://www.omron.com.cn/other/Privacy.html
策链接
(2)服务类型:运动改善服务
第三方公司名称 舒华体育股份有限公司
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第40/81⻚

## Page 41

2026/9/29 17:42
产品/类型 跑步机
我们分享的个人信
无
息
我们从第三方获取 设备蓝牙MAC地址、速度、步数、运动距
的个人信息 离、运动时长、消耗、心率
第三方可能调用的
无
权限
实现功能/场景 向用户展示跑步机相关指标
处理目的 向用户展示跑步机相关指标
处理方式 蓝牙传输
联系方式 https://www.shuhua.cn/
第三方公司名称 浙江立久佳运动器材有限公司
产品/类型 跑步机
我们分享的个人信
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第41/81⻚

## Page 42

2026/9/29 17:42
息 无
我们从第三方获取 设备蓝牙MAC地址、速度、步数、运动距
的个人信息 离、运动时长、消耗、心率
第三方可能调用的
无
权限
实现功能/场景 向用户展示跑步机相关指标
处理目的 向用户展示跑步机相关指标
处理方式 蓝牙传输
联系方式 https://www.lijiujia.ltd/
第三方公司名称 浙江易跑健康科技有限公司
产品/类型 跑步机
我们分享的个人信
无
息
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第42/81⻚

## Page 43

2026/9/29 17:42
我们从第三方获取 设备蓝牙MAC地址、速度、步数、运动距
的个人信息 离、运动时长、消耗、心率
第三方可能调用的
无
权限
实现功能/场景 向用户展示跑步机相关指标
处理目的 向用户展示跑步机相关指标
处理方式 蓝牙传输
联系方式 http://www.ypoosports.com/
(3)服务类型:运动健康数据共享
1、健康服务SDK:
第三方主体:支付宝(中国)网络技术有限公司、南宁
市青秀区训练记录软件开发工作室、中央宣传部宣传舆
情研究中心、广州云科信息科技有限公司(练练)
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第43/81⻚

## Page 44

2026/9/29 17:42
我们分享的个人信息:无
我们从第三方获取的个人信息:训练基础数据(开始时
间、结束时间、最高心率、平均心率、数据客户端唯一
标识(如有)、训练标题、总容量、运动时长、消耗、
训练动作数据(动作名称、轮数、配重、次数、完成状
态)、实时心率数据
第三方可能调用的权限:无
实现功能/场景:在“健康”运动记录展示相应的数据。
处理目的:在“健康”运动记录展示相应的数据。
处理方式:健康服务SDK传输
联系方式:
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第44/81⻚

## Page 45

2026/9/29 17:42
支付宝(中国)网络技术有限公司 https://render.alipa
y.com/p/yuyan/180020010001196791/preview.html?ag
reementId=AG00000132
南宁市青秀区训练记录软件开发工作室邮箱:snakegea
r@163.com
中央宣传部宣传舆情研究中心 https://www.51callcente
r.com/newsinfo/163/3582414/
广州云科信息科技有限公司(练练)https://www.gzyu
nke.cn/
第三方隐私政策链接:
支付宝(中国)网络技术有限公司 https://render.alipa
y.com/p/yuyan/180020010001196791/preview.html?ag
reementId=AG00000132
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第45/81⻚

## Page 46

2026/9/29 17:42
南宁市青秀区训练记录软件开发工作室 https://xunji.g
xzckj.com/xunji_android_policy
中央宣传部宣传舆情研究中心 https://im-pages.xuexi.c
n/im-page-groups/protection-policy/index.html?show
menu=false
广州云科信息科技有限公司(练练)https://lianlian.gz
yunke.cn/privacy.html
第三方主体:OPPO广东移动通信有限公司
我们分享的个人信息:步数
我们从第三方获取的个人信息:无
第三方可能调用的权限:无
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第46/81⻚

## Page 47

2026/9/29 17:42
实现功能/场景:用于展示在手机锁屏页面
处理目的:用于展示在手机锁屏页面
处理方式:健康服务SDK传输
联系方式:https://www.oppo.com/cn/contact/
第三方隐私政策链接:https://privacy.oppo.com/cn/pol
icy/
2、健康服务云端API:
第三方主体:支付宝(中国)网络技术有限公司、北京
卡 路 里 科 技 有 限 公 司 ( Keep ) 、 成 都 乐 动 信 息 技 术 有
限 公 司 ( 咕 咚 ) 、 广 州 悦 跑 信 息 科 技 有 限 公 司 ( 悦 跑
圈)、深圳市悦动天下科技有限公司(悦动圈)
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第47/81⻚

## Page 48

2026/9/29 17:42
我们分享的个人信息:账号昵称、位置信息、心率、步
数、日常活动数据(当天消耗目标、当天步数目标、运
动卡路里、运动距离、总活动次数、运动步数、锻炼总
时长)、用户绑定设备信息(设备名称、设备SN码、
设备类型、设备制造厂商)、血氧(血氧饱和度类型、
血氧饱和度值、平均血氧饱和度、最大血氧饱和度、最
小血氧饱和度)、压力、睡眠数据、运动记录
我们从第三方获取的个人信息:无
第三方可能调用的权限:无
实现功能/场景:用户授权第三方读取其在“健康”中存
储的个人数据
处理目的:为用户提供将个人数据共享给第三方应用、
服务的功能
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第48/81⻚

## Page 49

2026/9/29 17:42
处理方式:云端API传输
联系方式:
支付宝(中国)信息技术有限公司 https://mobile.alipa
y.com/
北京卡路里科技有限公司(Keep) https://www.gotok
eep.com/
成都乐动信息技术有限公司(咕咚)https://www.codo
on.com/
广州悦跑信息科技有限公司(悦跑圈)https://www.the
joyrun.com/
深圳市悦动天下科技有限公司(悦动圈)https://www.
51yund.com/
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第49/81⻚

## Page 50

2026/9/29 17:42
第三方隐私政策链接:
支付宝(中国)信息技术有限公司 https://render.alipa
y.com/p/yuyan/180020010001196791/preview.html?ag
reementId=AG00000132
北京卡路里科技有限公司(Keep) https://www.gotok
eep.com/privacy
成都乐动信息技术有限公司(咕咚)https://tms.codoo
n.com/cms/pro/1515984586540zrCU6w.html
广州悦跑信息科技有限公司(悦跑圈)https://www.the
joyrun.com/privacy.html
深圳市悦动天下科技有限公司(悦动圈)https://cftwe
b.3g.qq.com/privacy/agreement?appid=10570223
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第50/81⻚

## Page 51

2026/9/29 17:42
第三方主体:深圳市两步路信息技术有限公司(两步路
户外助手)
我们分享的个人信息:账号昵称、位置信息、心率、步
数、日常活动数据(当天消耗目标、当天步数目标、运
动卡路里、运动距离、总活动次数、运动步数、锻炼总
时长)、用户绑定设备信息(设备名称、设备类型、设
备型号)、血氧(血氧饱和度类型、血氧饱和度值、平
均血氧饱和度、最大血氧饱和度、最小血氧饱和度)、
压力、睡眠数据、运动记录
我们从第三方获取的个人信息:开始时间、结束时间、
轨迹、总距离、总时长、总消耗、总步数、平均配速、
最快配速、(实时配速、每公里配速、平均心率、最大
心率、实时心率、平均步频、最快步频、实时步频、平
均步幅、最大步幅、实时步幅)(如有)、累计爬升、
最 高 海 拔 、 实 时 海 拔 、 平 均 速 度 、 最 快 速 度 、 实 时 速
度 、 ( 设 备 类 型 、 设 备 型 号 、 设 备 名 称 、 蓝 牙 MAC 地
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第51/81⻚

## Page 52

2026/9/29 17:42
址)(如有)
第三方可能调用的权限:无
实现功能/场景:用户授权第三方读取其在“健康”中存
储的个人数据;在“健康”运动记录展示相应的数据。
处理目的:为用户提供将个人数据共享给第三方应用、
服务的功能;在“健康”运动记录展示相应的数据。
处理方式:云端API传输
联系方式:
深圳市两步路信息技术有限公司(两步路户外助手)ht
tps://www.2bulu.com/
第三方隐私政策链接:
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第52/81⻚

## Page 53

2026/9/29 17:42
深圳市两步路信息技术有限公司(两步路户外助手)ht
tps://www.2bulu.com/about/privacy.htm
第三方主体:上海九列信息科技有限公司
我 们 分 享 的 个 人 信 息 : GPS 、 步 数 、 距 离 、 消 耗 、 心
率、速度、设备类型、设备型号、设备名称、运动开始
时间、运动结束时间
我们从第三方获取的个人信息:无
第三方可能调用的权限:无
实现功能/场景:数据共享给第三方小程序并进行显示
处理目的:数据共享给第三方小程序并进行显示
处理方式:云端API传输
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第53/81⻚

## Page 54

2026/9/29 17:42
联系方式:soccerlife@aliyun.com
第三方隐私政策链接:https://mp.weixin.qq.com/s/dtjj
AgttpqMmu0ZxCxFnUA
第三方主体:跑跑糖(北京)运动科技有限公司
我们分享的个人信息:运动记录
我们从第三方获取的个人信息:无
第三方可能调用的权限:无
实现功能/场景:数据共享给第三方小程序并进行显示
处理目的:数据共享给第三方小程序并进行显示
处理方式:云端API传输
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第54/81⻚

## Page 55

2026/9/29 17:42
联系方式:feedback@pptsport.com
第三方隐私政策链接:https://www.pptsport.com/priva
cy.html
产品/类型:通用场景文字识别服务
第三方公司名称:北京百度网讯科技有限公司
第三方收集的个人信息:医疗健康报告类图片
我们从第三方获取的个人信息:OCR提取后的文本
第三方可能调用的权限:无
实现功能/场景:健康中使用到OCR提取文本的功能,如
健康档案的数据解析
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第55/81⻚

## Page 56

2026/9/29 17:42
处理目的:支持健康档案中医疗健康报告的结构化展示
及归档
处理方式:云端API传输
联系方式:https://ai.baidu.com
第三方隐私政策链接:https://privacy.baidu.com/policy/
PrivacyPolicy
产品/类型:图像智能处理服务
第三方公司名称:上海盈五蓄数据科技有限公司
第三方收集的个人信息:医疗健康报告类图片
我们从第三方获取的个人信息:经矫正增强后的图片
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第56/81⻚

## Page 57

2026/9/29 17:42
第三方可能调用的权限:无
实现功能/场景:健康中使用到图片矫正增强的功能,如
健康档案的数据解析
处理目的:提高健康档案中数据提取的准确性
处理方式:云端API传输
联系方式:https://www.textin.com
第三方隐私政策链接:https://www.textin.com/privacy
3、客户端API:
第三方主体:深圳市腾讯计算机系统有限公司、支付宝
(中国)网络技术有限公司
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第57/81⻚

## Page 58

2026/9/29 17:42
我们分享的个人信息:步数
我们从第三方获取的个人信息:无
第三方可能调用的权限:无
现功能/场景:用户授权第三方读取其在“健康”中存储
的个人数据
处理目的:在微信运动中展示、在支付宝运动中展示
处理方式:客户端接又传输
联系方式:
深圳市腾讯计算机系统有限公司 https://kf.qq.com/
支付宝(中国)信息技术有限公司 https://mobile.alipa
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第58/81⻚

## Page 59

2026/9/29 17:42
y.com/
第三方隐私政策链接:
深圳市腾讯计算机系统有限公司https://support.weixin.
qq.com/cgi-bin/mmsupport-bin/readtemplate?t=weixin
_agreement
支 付 宝 ( 中 国 ) 信 息 技 术 有 限 公 司 https://render.alipa
y.com/p/yuyan/180020010001196791/preview.html?ag
reementId=AG00000132
第三方主体: OPPO广东移动通信有限公司
我们分享的个人信息:运动记录、睡眠数据、经期、步
数、心率
我们从第三方获取的个人信息:无
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第59/81⻚

## Page 60

2026/9/29 17:42
第三方可能调用的权限:无
现功能/场景:用于在手机负一屏卡片上展示
处理目的:用于在手机负一屏卡片上展示
处理方式:客户端接又传输
联系方式:https://www.oppo.com/cn/smartphones/
隐私政策:https://privacy.oppo.com/cn/policy/
(4)服务类型:紧急救援服务
第三方主体:远盟康健科技有限公司、深圳位置网科技
有限公司
我们分享的个人信息::手机号码、位置信息、紧急联
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第60/81⻚

## Page 61

2026/9/29 17:42
系人、性别、年龄、身高、体重、血型、过敏药物、既
往病史、常用药物
我们从第三方获取的个人信息:无
第三方可能调用的权限:无
实现功能/场景:手表端使用紧急呼叫服务
处理目的:实现定位信息、急救档案传输、给紧急联系
人发送求救短信
处理方式:云端接又传输
联系方式:
远盟康健科技有限公司 https://www.healthlink.cn/
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第61/81⻚

## Page 62

2026/9/29 17:42
深圳位置网科技有限公司 http://www.weizhi.com/
第三方隐私政策链接:
远盟康健科技有限公司 https://lvtong.healthlink.cn/sha
nhu-manager/html/kaimenhong/registerYinsi.html?v=2
021
深圳位置网科技有限公司 http://www.weizhi.com/yinsi
zhengce.html
(5)服务类型:eSIM服务
第三方主体:中国电信有限公司、中国移动有限公司、
中国联通有限公司
我们分享的个人信息:穿戴设备的(IMEI、SN、IMS
I、ICCID、EID)、设备型号
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第62/81⻚

## Page 63

2026/9/29 17:42
我们从第三方获取的个人信息:无
第三方可能调用的权限:无
实现功能/场景:为用户提供穿戴设备的eSIM功能
处理目的:为用户提供穿戴设备的eSIM功能
处理方式:客户端接又传输
联系方式:
中国电信有限公司 http://www.chinatelecom.com.cn/
中国移动有限公司 http://www.10086.cn/
中国联通有限公司 http://www.chinaunicom.com.cn/
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第63/81⻚

## Page 64

2026/9/29 17:42
第三方隐私政策链接:
中 国 电 信 有 限 公 司 https://www.189.cn/fj/sy_yw/sy_y
w_gwzn/120189.html
中 国 移 动 有 限 公 司 https://www.he.10086.cn/protocol/
pc/PersonalInfoProtectionPolicy.html
中 国 联 通 有 限 公 司 http://m.client.10010.com/mobileS
ervice/tuwenhunpai/notice_1527478459203.html
(6)服务类型:车钥匙服务
第三方主体:比亚迪汽车工业有限公司、腾势汽车销售
服务有限公司、深圳仰望汽车销售有限公司、深圳方程
豹汽车销售有限公司
我们分享的个人信息:设备CPLC、设备厂商、设备名
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第64/81⻚

## Page 65

2026/9/29 17:42
称
我们从第三方获取的个人信息:车架号、车型号
第三方可能调用的权限:无
实现功能/场景:通过NFC能力,将手表绑定为车钥匙
处理目的:通过NFC能力,将手表绑定为车钥匙
处理方式:客户端接又传输、云端接又传输
联系方式:
比 亚 迪 汽 车 工 业 有 限 公 司 https://www.bydauto.com.c
n/
腾势汽车销售服务有限公司 https://www.tengshiauto.c
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第65/81⻚

## Page 66

2026/9/29 17:42
om/
深圳仰望汽车销售有限公司 https://www.yangwangaut
o.com/
深圳方程豹汽车销售有限公司https://www.fangchengb
ao.com/
第三方隐私政策链接:
比亚迪汽车工业有限公司 https://profilesys.bydauto.co
m.cn/dynasty/h5/app/privacy.html
腾 势 汽 车 销 售 服 务 有 限 公 司 https://i.tengshiauto.com/
h5/app/privacy.html
深 圳 仰 望 汽 车 销 售 有 限 公 司 https://profilesys.yangwan
gauto.com/h5/app/privacy.html
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第66/81⻚

## Page 67

2026/9/29 17:42
深 圳 方 程 豹 汽 车 销 售 有 限 公 司 https://profilesys-cn.fan
gchengbaoapp.com/h5/app/privacy.html
(7)服务类型:公交卡服务
第三方主体:深圳市雪球科技有限公司、深圳市微付充
科技有限公司、深圳市可为信息技术有限公司、上海复
旦微电子集团股份有限公司、成都天府通金融服务股份
有限公司、广东岭南通股份有限公司
第三方收集的个人信息:设备芯片cplc,设备型号
我们从第三方获取的个人信息:公交卡卡号,余额,交
易记录
实现功能/场景:用于用户开通公交卡、充值、卡片迁
移、删卡退款
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第67/81⻚

## Page 68

2026/9/29 17:42
处理目的:用于用户开通公交卡、充值、卡片迁移、删
卡退款
处理方式:接又传输
联系方式:
深 圳 市 雪 球 科 技 有 限 公 司 官 网 https://snowballtech.co
m/
深圳市微付充科技有限公司官网https://www.vfuchong.
com/index.php?m=About
深圳市可为信息技术有限公司官网http://www.cardshar
e.cn/
上海复旦微电子集团股份有限公司官网http://www.fms
h.com/
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第68/81⻚

## Page 69

2026/9/29 17:42
成都天府通金融服务股份有限公司官网http://www.cdtf
t.cn/pc/
广东岭南通股份有限公司官网 http://www.lingnanpass.
com/
第三方隐私政策链接:
深圳市雪球科技有限公司
https://snowballtech.com/privacy-policy/
深圳市微付充科技有限公司
https://www.vfuchong.com/h5/h5.html
深圳市可为信息技术有限公司
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第69/81⻚

## Page 70

2026/9/29 17:42
http://www.cardshare.cn/index.php?id=108
成都天府通金融服务股份有限公司
https://tsmapp.cdtft.cn/apkp_new/viewModel/tftAgree
ment?agreementType=10
广东岭南通股份有限公司
https://wupd.lingnanpass.com:7058/APPMall/androidP
rivacy.html
上海复旦微电子集团股份有限公司
https://rfid.fm-uivs.com/nfcTools/static/dt160_privac
y.html
第三方主体:北京雷森科技发展有限公司
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第70/81⻚

## Page 71

2026/9/29 17:42
第三方收集的个人信息:设备芯片cplc,设备型号、手
机号
我们从第三方获取的个人信息:公交卡卡号,余额,交
易记录
实现功能/场景:用于用户开通公交卡、充值、卡片迁
移、删卡退款
处理目的:用于用户开通公交卡、充值、卡片迁移、删
卡退款
处理方式:接又传输
联系方式:
北 京 雷 森 科 技 发 展 有 限 公 司 官 网 https://b2b.huangye8
8.com/gongsi/1156542/
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第71/81⻚

## Page 72

2026/9/29 17:42
第三方隐私政策链接:
北京雷森科技发展有限公司
请 复 制 至 浏 览 器 打 开 https://www.opentsm.cn:7018/bss
smp/PrivacyText.jsp
(8)服务类型:投保服务(投保功能由三方提供)
投保功能由第三方公司提供
第三方主体:深圳市中诚安信保险经纪有限公司
第三方收集的个人信息:手机号、姓名、身份证号、短
信验证码
我们从第三方获取的个人信息:无
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第72/81⻚

## Page 73

2026/9/29 17:42
实现功能/场景:用户主动填写投保信息,使用投保功
能
处理目的:填写投保信息,使用投保功能
处理方式:服务由三方公司提供,数据由三方公司处理
联系方式:https://www.cib-web.com/
隐私政策:https://www.cib-web.com/privacy.php
(9)服务类型:一键问医生(功能由三方提供)
第三方主体:蚂蚁逸康(广州)信息技术有限公司
第三方收集的个人信息:血氧、心率、血压、用户睡眠
质量
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第73/81⻚

## Page 74

2026/9/29 17:42
我们从第三方获取的个人信息:支付宝账号
第三方可能调用的权限:相机权限、照片和视频、存储
空间(Android13系统以下)
实现功能/场景:用于辅助制定健康运动指导和就医咨
询
处理目的:用于辅助制定健康运动指导和就医咨询
处理方式:接又传输
联系方式:95188
第 三 隐 私 政 策 链 接 : https://render.alipay.com/p/c/180
021120000000474/index.html?agreementId=AG01000
662
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第74/81⻚

## Page 75

2026/9/29 17:42
https://render.alipay.com/p/c/180021120000000048/in
dex.html?agreementId=AG01000345
(10)服务类型:算法大模型
产品/类型:安第斯大模型
第三方公司名称:OPPO(重庆)智能科技有限公司
第三方模型备案号:ChongQing-AnDiSiDaMoXing-20
231222
第三方收集的个人信息:用户输入文本
我们从第三方获取的个人信息:无
第三方可能调用的权限:无
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第75/81⻚

## Page 76

2026/9/29 17:42
实现功能/场景:对用户的问题进行理解回复
处理目的:支持健康助手对话能力
处理方式:云端API
联系方式:https://andesgpt.oppoer.me/
第三方隐私政策链接:https://static-bot.nearme.com.cn/
dailyh5/agreement/privacy/1.0.4.pdf
产品/类型:混元大模型
第三方公司名称:腾讯云计算(北京)有限责任公司
第三方模型备案号:440305295988701230071
第三方收集的个人信息:用户输入文本、用户输入的报
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第76/81⻚

## Page 77

2026/9/29 17:42
告图片(OPPO侧进行OCR文字提取,脱敏后输入给第
三方)
我们从第三方获取的个人信息:分析结果和建议
第三方可能调用的权限:无
实现功能/场景:对用户的问题进行理解回复
处理目的:支持健康助手对话能力
处理方式:云端API
联系方式:4009100100
第 三 方 隐 私 政 策 链 接 :https://cloud.tencent.com/docum
ent/product/301/11470
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第77/81⻚

## Page 78

2026/9/29 17:42
产品/类型:腾讯混元大模型多模态算法
第三方公司名称:腾讯云计算(北京)有限责任公司
第三方模型备案号:440305295988701240155
第三方收集的个人信息:用户输入的图片
我们从第三方获取的个人信息:分析结果和建议
第三方可能调用的权限:无
实现功能/场景:对用户的图片进行理解回复
处理目的:支持健康助手对话能力
处理方式:云端API
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第78/81⻚

## Page 79

2026/9/29 17:42
联系方式:https://cloud.tencent.com/document/produc
t/301/59792
第 三 方 隐 私 政 策 链 接 : https://cloud.tencent.com/docu
ment/product/301/97822
产品/类型:腾讯云Deepseek-R1大模型
第三方公司名称:腾讯云计算(北京)有限责任公司
第三方模型备案号:DeepSeek-1101089705501012400
11
第三方收集的个人信息:用户输入文本,用户标签
我们从第三方获取的个人信息:分析结果和建议
第三方可能调用的权限:无
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第79/81⻚

## Page 80

2026/9/29 17:42
实现功能/场景:对用户的问题进行理解回复
处理目的:支持健康助手对话能力
处理方式:云端API
联系方式:4009100100/Dataprivacy@tencent.com
第 三 方 隐 私 政 策 链 接 :https://cloud.tencent.com/docum
ent/product/301/11470
产品/类型:腾讯云Deepseek模型
第三方公司名称:腾讯云计算(北京)有限责任公司
第三方模型备案号:Beijing-DeepseekChat-202404280
016
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第80/81⻚

## Page 81

2026/9/29 17:42
第三方收集的个人信息:用户输入文本、用户标签
我们从第三方获取的个人信息:无
第三方可能调用的权限:无
实现功能/场景:对用户的问题进行理解回复
处理目的:支持对话能力
处理方式:API调用
联系方式:Dataprivacy@tencent.com
第 三 方 隐 私 政 策 链 接 :https://rule.tencent.com/rule/202
404080003
https://sport.health.heytapmobi.com/h5/statement/index.html#/?ne...com.heytap.health&contentType=7&osType=1&versionId=1753862322523 第81/81⻚
