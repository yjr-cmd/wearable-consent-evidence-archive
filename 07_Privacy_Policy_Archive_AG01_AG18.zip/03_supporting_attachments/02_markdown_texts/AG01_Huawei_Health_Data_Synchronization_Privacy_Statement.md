# Huawei Health Data Synchronization Service Privacy Statement

- Case: AG01
- Brand: Huawei
- Material type: Data synchronization service privacy statement
- Original filename: `关于运动健康数据同步服务与隐私的声明.pdf`
- Original format: PDF
- Archive role: Supporting attachment for documentary verification of health-data synchronization disclosures.

> Note: This Markdown file is a text-access copy generated from the archived original. The original file remains the controlling archived source.

## Page 1

关于运动健康数据同步服务与隐私的声明 2026/9/29 17:37
关于运动健康数据同
步服务与隐私的声明
更新日期:2022年02月28
日
运动健康数据同步服务
是由华为软件技术有限
公司(注册地:南京市
雨花台区软件大道101
号)(以下简称“我们”
或“华为”)为您提供运
动健康类设备数据同步
服务。华为非常重视您
的个人信息和隐私保
护,我们将会按照法律
要求和业界成熟的安全
标准,为您的个人信息
提供相应的安全保护措
施。
版本变更说明
因业务发展、优化,导
致隐私声明更新,请您
仔细阅读此隐私声明的
变更内容:
运动健康数据同步服务
的个人信息处理者由华
为终端有限公司变更为
华为软件技术有限公
司。华为软件技术有限
公司将继续履行个人信
息处理者的义务,您可
以按照本隐私声明“如
何联系我们”章节中说
明的方式与我们取得联
系。
在对未成年人的保护章
节中,补充对于未成年
人保护的描述。
我们会使用您的个人信
https://legal.cloud.huawei.com/terms/scope/huawei/ailife-healthdat...statement.htm?code=CN&branchid=0&language=zh-CN&contenttag=default 第1/2⻚

## Page 2

关于运动健康数据同步服务与隐私的声明 2026/9/29 17:37
https://legal.cloud.huawei.com/terms/scope/huawei/ailife-healthdat...statement.htm?code=CN&branchid=0&language=zh-CN&contenttag=default 第2/2⻚
