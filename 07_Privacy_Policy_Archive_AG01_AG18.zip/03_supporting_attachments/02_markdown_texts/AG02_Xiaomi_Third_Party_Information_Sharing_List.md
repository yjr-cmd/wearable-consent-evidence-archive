# Xiaomi Third-Party Information Sharing List

- Case: AG02
- Brand: Xiaomi
- Material type: Third-party information sharing list
- Original filename: `‎小米.pdf`
- Original format: PDF
- Archive role: Supporting attachment for documentary verification of third-party sharing and SDK disclosures.

> Note: This Markdown file is a text-access copy generated from the archived original. The original file remains the controlling archived source.

## Page 1

2026/9/29 17:40
为保障产品和服务的稳定运行或实现相关功能,您的个人信息可能会在各服务提供方之间共享,我们将
根据法律法规要求并参照行业最佳实践,不断完善和提升对您个人信息的安全保障水平。我们严格遵循
隐私权政策的约定,一旦涉及共享您的个人敏感信息或新增共享方,我们将再次征求您的授权同意。具
体共享情况说明如下:
高德地图
第三方公司名称: 高德软件有限公司
共享类型: 内嵌 SDK (高德地图 SDK)
共享信息: 位置信息、设备信息(IP 地址、GNSS 信息、WiFi 状态、WiFi 参数、WiFi 列表、基站信
息、信号强度的信息、蓝牙信息、传感器信息(矢量、加速度、压力、方向、地磁、加速度)、设备
信号强度信息)、设备标识信息(IMEI、IDFA、IDFV、Android ID、MEID、MAC 地址、OAID、
IMSI、硬件序列号)、当前应用信息(应用名、应用版本号)、设备参数及系统信息(系统属性、设
备型号、操作系统)、通话状态信息(通过此接口获取基站信息和网络信息用于定位)
使用目的: 给应用返回用户位置信息、在地图图面上展示用户位置
使用场景: 用户使用户外运动功能
共享方式: SDK 本机采集
涉及权限: 定位权限
第三方个人信息处理规则: https://lbs.amap.com/pages/privacy/
微信分享
第三方公司名称: 深圳市腾讯计算机系统有限公司
共享类型: 内嵌 SDK (微信分享 SDK)
共享信息: 图片(运动数据图、APP 下载链接二维码),地理位置信息(轨迹图),用户自选照片和
输入文字,平台注册 APPID
使用目的: 支持微信分享
使用场景: 用户分享
共享方式: SDK 本机采集
第三方个人信息处理规则: https://weixin.qq.com/cgi-bin/readtemplate?lang=zh_CN&t=weixin_agr
eement&s=privacy
华米数据同步
第三方公司名称: 安徽华米信息科技有限公司
共享类型: 内嵌 SDK (华米 SDK)
共享信息: 固件设备标识信息(设备 SN),步数、心率、卡路里、压力、血氧、睡眠、运动、PAI
使用目的: 为实现华米旗下手环的绑定以及数据同步
使用场景: 用户使用华米旗下手环时
https://watch.iot.mi.com/html/data_share_explain3/index.html?locale=zh_cn 第1/7⻚

## Page 2

2026/9/29 17:40
共享方式: SDK 本机采集
第三方个人信息处理规则: https://huami.gitbooks.io/iot/content/android.html
数据导入
第三方公司名称: 安徽华米信息科技有限公司
共享类型: API (华米开放接口)
共享信息: 步数、心率、卡路里、压力、房颤、血氧、最大摄氧量、睡眠、运动、PAI 及女性经期
使用目的: 为从“Zepp Life”迁移到“小米运动健康”的用户提供快捷的数据导入功能
使用场景: 用户使用数据导入功能时
共享方式: 后台接口传输
第三方个人信息处理规则: https://upload-cdn.huami.com/tposts/2314789
微信运动
第三方公司名称: 腾讯科技(深圳) 有限公司
共享类型: API (微信运动)
共享信息: 步数,去标识化的用户身份 ID
使用目的: 为实现用户在微信步数排行榜中查看排名功能
使用场景: 用户使用微信数据接入功能时
共享方式: 后台接口传输
第三方个人信息处理规则: https://developers.weixin.qq.com/miniprogram/dev/api/open-api/weru
n/wx.shareToWeRun.html
支付宝运动
第三方公司名称: 支付宝(杭州)信息技术有限公司
共享类型: API (支付宝运动)
共享信息: 步数,去标识化的用户身份 ID
使用目的: 为实现用户在支付宝步数排行榜中查看排名
使用场景: 用户使用支付宝数据接入功能时
共享方式: 后台接口传输
第三方个人信息处理规则:https://opendocs.alipay.com/mini/introduce/rundata
小米账号登录
第三方公司名称: 小米科技有限责任公司
共享类型: SDK(小米账号 SDK)
共享信息: 设备标识信息(在 Android Q 上的 OAID),小米账号和密码
使用目的: 为实现登录账号功能
https://watch.iot.mi.com/html/data_share_explain3/index.html?locale=zh_cn 第2/7⻚

## Page 3

2026/9/29 17:40
使用场景: 用户使用小米账号登录功能时
共享方式: SDK 本机采集
第三方个人信息处理规则: https://privacy.mi.com/miaccount/zh_CN/
小爱同学(超级小爱)语音助手
第三方公司名称: 小米科技有限责任公司
共享类型: SDK(小爱同学 SDK)
共享信息: 小米账号信息、用户语音信息、设备标识信息(oaid)、通讯录信息(本地处理)、SSID
(Wi-Fi名称);运动时⻓、运动距离、心率、卡路里、步频、步数、配速信息
使用目的: 为穿戴类设备提供小爱同学相关功能
使用场景: 用户使用小爱同学时
共享方式: SDK 本机采集
第三方个人信息处理规则: https://developers.xiaoai.mi.com/documents/Home?type=/api/doc/rend
er_markdown/new/XiaoaiPrivacy
卡模拟服务
第三方公司名称: 北京小米移动软件有限公司
共享类型: SDK(小米 TSM SDK)
共享信息: 小米账号信息、设备标识信息(IMEI/SN 号)、手表/手环设备信息(CPLC)、公交卡/⻔卡信
息
使用目的: 为了给支持 NFC 功能的穿戴类设备提供卡模拟服务
使用场景: 用户使用 NFC 功能时
共享方式: SDK 本机采集
第三方个人信息处理规则: https://sf.pay.xiaomi.com/views/smartCardProtocol/privacyPolicy.html
数据统计
第三方公司名称: 小米科技有限责任公司
共享类型: SDK(小米统计 onetrack SDK)
共享信息: 设备标识信息(oaid)、⻚面访问事件、应用崩溃日志(应用包名版本号,手机型号)、
设备和系统参数(手机系统以及版本号,型号) 、应用的 appid、渠道号、是否加入用户体验、是否同
意隐私协议
使用目的: 用于数据统计和分析
使用场景: 用户使用应用功能时
共享方式: SDK 本机采集
第三方个人信息处理规则: https://dev.mi.com/docs/stat/user_guide/#1
小米社区排名
https://watch.iot.mi.com/html/data_share_explain3/index.html?locale=zh_cn 第3/7⻚

## Page 4

2026/9/29 17:40
第三方公司名称: 小米科技有限责任公司
共享类型: API(小米社区)
共享信息: 步数,小米账号信息
使用目的: 用户在小米社区排行榜中查看排名功能
使用场景: 用户使用小米社区时
共享方式: SDK 本机采集
第三方个人信息处理规则: https://privacy.mi.com/xiaomicommunity/zh_CN/
穿戴设备显示
第三方公司名称: 小米科技有限责任公司
共享类型: SDK(米家 IoT SDK)
共享信息: 设备标识(IMEI)、SSID(Wi-Fi名称)、手机型号、系统版本信息、用户账号信息、智能设
备关联信息及使用者信息、用户反馈日志
使用目的: 用于鉴别用户身份,显示用户名下可控制的穿戴设备
使用场景: 用户使用穿戴设备时
共享方式: SDK 本机采集
第三方个人信息处理规则: https://iot.mi.com/new/doc/policy/secret
小米推送
第三方公司名称: 北京小米移动软件有限公司
共享类型: SDK(小米推送 SDK)
共享信息: Mipush reg id,设备标识(Android ID)
使用目的: 为用户提供推送功能
使用场景: 用户收到推送时
共享方式: SDK 本机采集
第三方个人信息处理规则: https://dev.mi.com/console/doc/detail?pId=1822
Milink 服务
第三方公司名称: 北京小米移动软件有限公司
共享类型: SDK (Milink SDK)
共享信息: 设备标识信息(IMEI 号/OAID、Android ID),课程 URL,运动数据
使用目的: 将运动课程投屏到电视上
使用场景: 用户使用课程投屏功能时
共享方式: SDK 本机采集
第三方个人信息处理规则: https://privacy.mi.com/milink/zh_CN/
支付宝支付
https://watch.iot.mi.com/html/data_share_explain3/index.html?locale=zh_cn 第4/7⻚

## Page 5

2026/9/29 17:40
第三方公司名称: 支付宝(中国)网络技术有限公司
共享类型: SDK (支付宝支付 SDK)
共享信息: 设备标识信息(MAC 地址),网络信息
使用目的: 充值公交卡
使用场景: 用户充值公交卡时
共享方式: SDK 本机采集
第三方个人信息处理规则: https://opendocs.alipay.com/open/54/01g6qm
体感互动课程
第三方公司名称: 乐渊网络(上海)科技有限公司
共享类型: 爱动 SDK
共享信息: 小米账号信息(头像、昵称、性别)、心率、卡路里
使用目的: 方便使用小米账号登录、计算运动情况
使用场景: 使用体感互动课程功能时
共享方式: SDK 本机采集
第三方个人信息处理规则:https://coach.aidong.me/ad_agreement/index.html#/privacy
米币支付
第三方公司名称: 北京瓦力网络科技有限公司
共享类型: SDK(米币 SDK)
共享信息: 小米 ID、订单信息(订单编号、交易金额)
使用目的: 实现使用微信支付、支付宝、小米钱包等支付功能
使用场景: 用户在安卓端购买付费表盘时
共享方式: SDK 本机采集
第三方个人信息处理规则: https://m.mibi.mi.com/license/privacy?region=CN&lang=zh
睡眠节律障碍筛查计划
第三方公司名称:北京大学国际医院
共享信息:姓名、联系方式、睡眠报告数据
使用目的: 供合作医院进行睡眠疾病与睡眠健康排查参考
使用场景: 用户参与睡眠节律异常筛查计划并前往合作医院就诊时
共享方式: 后台接口传输
第三方个人信息处理规则: https://fe.pkucare.com/outpatient/mine/privacy?title=%E9%9A%90%E
7%A7%81%E6%94%BF%E7%AD%96-%E5%B0%8F%E7%A8%8B%E5%BA%8F&showTitle
=%E9%9A%90%E7%A7%81%E6%94%BF%E7%AD%96&org_code=112628
小米健康研究
https://watch.iot.mi.com/html/data_share_explain3/index.html?locale=zh_cn 第5/7⻚

## Page 6

2026/9/29 17:40
第三方公司名称:小米科技有限责任公司
共享类型:应用间传输(小米运动健康)
共享信息:账号信息(昵称、小米 ID、 性别、生日、身高)、设备信息(设备名称、设备型号、设备连接
状态、固件版本、设备标识符(SN 码))、网络信息、心率、ECG 心电图、压力、血氧、睡眠、体
重、经期、血压、皮肤温度
使用目的:向小米健康研究合作医院医生展示,用于睡眠呼吸暂停研究、血压健康研究
使用场景: 当用户参与睡眠呼吸暂停研究、血压健康研究项目时
共享方式:API 本机采集
第三方个人信息处理规则:https://watch.iot.mi.com/html/privacy/index.html?type=research_privacy
_policy
QQ 音乐
第三方公司名称:深圳市腾讯计算机系统有限公司
共享类型: SDK
共享信息:步频
使用目的: 根据用户步频匹配音乐
使用场景: 用户运动模式下使用步频-音乐匹配功能
共享方式: SDK 本机采集
第三方个人信息处理规则:https://privacy.qq.com/document/preview/8d0f7e0efcfb4243a0b3a5404
5474387
汽⻋驾驶模式心率同步
第三方公司名称:小米汽⻋科技有限公司
共享类型:SDK
共享信息:心率
使用目的:手表汽⻋联动功能,汽⻋ Boost 模式展示心率
使用场景:用户佩戴手表驾驶汽⻋,并启动汽⻋ Boost 模式时
共享方式:SDK 本机采集
第三方个人信息处理规则:https://terms.mobile.iccc.xiaomiev.com/micarmobile/privacy
应用商店
第三方公司名称:小米科技有限责任公司
共享类型:应用商店 SDK
共享信息:小米账号 ID、设备标识(OAID)、设备型号、手机系统版本信息(android sdk level)、
手机系统语言、设备所设置的国家或地区、运营商信息、应用商店的版本信息、手机和手表已安装应
用信息
使用目的:用于浏览、下载、安装、更新应用程序
使用场景:当用户浏览、下载、安装、更新手表设备应用程序时
https://watch.iot.mi.com/html/data_share_explain3/index.html?locale=zh_cn 第6/7⻚

## Page 7

2026/9/29 17:40
共享方式:SDK 本机采集
第三方个人信息处理规则:https://privacy.mi.com/market-SmartWatch/zh_CN/
蚂蚁阿福
第三方公司名称:蚂蚁逸康(广州)信息技术有限公司
共享类型:API
共享信息:小米 ID,性别、年龄、身高、心率、睡眠、体重、饮⻝、压力、血氧、经期、运动记录
使用目的:用于身份识别;用于健康数据解读及辅助医生分析健康状况;
使用场景:当用户使用 AQ 解读服务及激活小米运动健康会员问诊服务时
共享方式:后台接口传输
第三方个人信息处理规则:https://render.alipay.com/p/yuyan/180020010001196791/preview.html?a
greementId=AG00000174
https://watch.iot.mi.com/html/data_share_explain3/index.html?locale=zh_cn 第7/7⻚
