# Huawei Third-Party Information Sharing List

- Case: AG01
- Brand: Huawei
- Material type: Third-party information sharing list
- Original filename: `第三方共享信息清单.pdf`
- Original format: PDF
- Archive role: Supporting attachment for documentary verification of third-party sharing disclosures.

> Note: This Markdown file is a text-access copy generated from the archived original. The original file remains the controlling archived source.

## Page 1

第三方共享信息清单 2026/9/29 17:36
第三方公司名称:荣耀终端有限公司
产品/类型:场景化建议服务(Suggestions Kit)(仅 Android)
共享信息类型:应用使用信息和状态(意图类型、操作类型、操作时间、事件状态、生效及失效时
间)
使用目的:为用户提供场景化的服务建议
使用场景:交通出行、影音娱乐、运动等
共享方式:SDK 本机采集
第三方个人信息处理规则:https://developer.honor.com/cn/docs/11003/guides/personal-data-
processing
第三方公司名称:使用通过华为帐号授权开放华为运动健康数据的第三方应用/服务
产品/类型:第三方应用/服务(仅 Android)
共享信息类型:个人基本资料(性别、出生日期、身高、体重),运动健康信息(运动信息(步
数、热量、距离、其他运动数据)、体重、心率、实时心率数据、压力数据、睡眠数据、血糖、血
压、血氧、体温)
使用目的:第三方应用/服务访问和展示运动健康数据、将自身数据写入运动健康以及提供相关服
务,以具体第三方应用/服务为准
使用场景:您使用第三方应用/服务并授权数据开放时,第三方应用/服务可获取您授权后的相关信
息
共享方式:后台接又传输
第三方个人信息处理规则:授权的第三方应用/服务中查看或联系第三方应用/服务查看
第三方公司名称:中国银联
产品/类型:银联可穿戴 SDK(仅 Android)
共享信息类型:设备标识符(SE 芯片的标识)、ODID/Android ID
使用目的:可穿戴设备银行卡生命周期管理
使用场景:开通、管理穿戴设备银行卡
共享方式:后台接又传输
第三方个人信息处理规则:https://user.95516.com/pages/misc/newAgree.html
第三方公司名称:苹果公司(Apple Inc.)
产品/类型:苹果 HealthKit(仅 iOS)
共享信息类型:运动信息(步数、步行+跑步距离、高山雪上运动距离、活动能量、骑行距离、体
https://legal.cloud.huawei.com.cn/terms/scope/huawei/health/privac...tatement.htm?code=cn&branchid=0&language=zh-cn&contenttag=3rdshare 第1/2⻚

## Page 2

第三方共享信息清单 2026/9/29 17:36
https://legal.cloud.huawei.com.cn/terms/scope/huawei/health/privac...atement.htm?code=cn&branchid=0&language=zh-cn&contenttag=3rdshare 第2/2⻚
