# Meizu Third-Party Information Sharing List

- Case: AG10
- Brand: Meizu (MYVU)
- Material type: Third-party information sharing list
- Original filename: `第三方信息共享清单.pdf`
- Original format: PDF
- Archive role: Supporting attachment for documentary verification of third-party sharing and SDK disclosures.

> Note: This Markdown file is a text-access copy generated from the archived original. The original file remains the controlling archived source.

## Page 1

第三方信息共享清单 2026/9/29 17:53
第三方信息共享清单
版本: 1.13
更新时间: 2025-09-10
敬请查看第三方信息共享清单
为保障本产品稳定运行或实现相关服务及功能,我们可能寻求和关联方、合作伙伴的合作,还可能会接入由
第三方提供的软件开发包(SDK)实现前述目的。在本清单中,我们列明了第三方相关信息,您可以进一步
通过目录中提供的链接或者路径查看第三方的数据使用和保护规则。
1. 收集个人信息的第三方SDK说明
关于这些第三方如何收集、使用您的个人信息,建议您参考第三方SDK的个人信息处理规则。请注意,第三
方提供的软件开发包(SDK)可能由于版本升级、策略调整等原因导致其个人信息处理类型发生变化,请以
其公示的官方说明为准。
SDK名称:高德地图开放平台 SDK
第三方名称:高德软件有限公司
使用场景:导航
使用目的:用于导航功能以及语音导航、获取用户当地当前的天气信息
个人信息种类:位置信息(精准位置、粗略位置、经纬度);设备信息(如IP 地址、GNSS信息、WiFi状
态、WiFi参数、WiFi列表、SSID、BSSID、基站信息、WiFi信号强度的信息、蓝牙信息、传感器信息(矢
量、加速度、压力、方向、地磁 、陀螺、温度、光敏、nema信号)、设备信号强度信息、外部存储目录;
设备标识信息(IMEI、IDFA、IDFV、Android ID、MEID、MAC地址、OAID、IMSI、ICCID、硬件序列
号)、当前应用信息(应用名、应用版本号)、设备参数及系统信息(系统属性、设备品牌及型号、操作系
统、运营商信息)、屏幕分辨率、车牌号
共享方式:内嵌SDK本机采集
隐私政策链接:https://lbs.amap.com/pages/privacy/
SDK名称:语音合成SDK
第三方名称:北京火山引擎科技有限公司
使用场景:提供语音交互服务
使用目的:用于评估当前WIFI网络质量并根据该质量信息做业务优化;用于统计授权设备数量;用于规避
某些版本系统的 bug;用于排查用户遇到的问题;用于发送网络请求;
个人信息种类:网络访问模式(WIFI状态);安卓ID(Andriod);操作系统(Andriod与iOS双端);用户
ID(Andriod与iOS双端);IP地址(Andriod与iOS双端);device_id(Andriod与iOS双端);文本数据
共享方式:服务端API传输
隐私政策链接:https://www.volcengine.com/docs/6561/116711
https://xj-platform.flyme.com/fms/policy/nocache/cf23bc5db2d95d2fae3353fdf160239f.html 第1/5⻚

## Page 2

第三方信息共享清单 2026/9/29 17:53
SDK名称:华为运动健康服务SDK(Android版)
第三方名称:华为软件技术有限公司
使用目的:为用户提供个人基本资料、运动健康信息存储和共享的平台;设备信息用于标记数据来源,华为
运动健康服务不会直接收集用户设备信息,具体传入设备信息由开发者确定;帐号信息用于用户的华为帐号
绑定三方服务时进行身份验证;应用信息用于开发者接入审核等生态运营活动。
个人信息种类:个人基本资料(包括身高和体重)、运动健康信息(包括步数、距离、爬高、速度、卡路
里、最大摄氧量、中高强度运动、活动数据、活动打点、锻炼、力量、跑步姿态、骑行、运动轨迹、睡眠数
据、心率、压力、心脏健康数据、血糖、血压、血氧、体温、营养数据、生殖数据)、设备信息(SN、
MAC、设备型号、Android ID、操作系统信息)、帐号信息(华为帐号信息)、应用信息(应用基本信
息)。
共享方式:内嵌SDK直接收集
隐私政策链接:
https://developer.huawei.com/consumer/cn/doc/HMSCore-Guides/sdk-privacy-instructions-0000001659248818
SDK名称:Bugly SDK (安卓版)
第三方名称:深圳市腾讯计算机系统有限公司
使用场景:排查崩溃问题,帮助APP提升稳定性
使用目的:识别Crash等问题是否与手机型号、手机品牌、软件系统版本、厂商系统版本、CPU架构有关;
在app发生闪退时,识别crash等问题是否与root、磁盘剩余空间、内存空间、网络类型、进程有关
个人信息种类:手机型号、手机品牌、Android系统版本、Android系统api等级、厂商系统版本、cpu架构类
型、设备是否root、磁盘空间占用大小、sdcard空间占用大小、内存空间占用大小、网络类型、应用当前正
在运行的进程名和PID
共享方式:内嵌SDK直接收集
隐私政策链接:https://privacy.qq.com/document/preview/fc748b3d96224fdb825ea79e132c1a56
SDK名称:Bugly SDK (iOS版)
第三方名称:深圳市腾讯计算机系统有限公司
使用场景:排查崩溃问题,帮助APP提升稳定性
使用目的:识别Crash等问题是否与手机型号、操作系统版本、操作系统内部版本号、网络状态、CPU架构
有关;在app发生闪退时,识别crash等问题是否与磁盘剩余空间、内存空间、运行时手机状态、越狱与否,
以及设备地区有关
个人信息种类:设备型号、操作系统版本、操作系统内部版本、wifi状态、cpu属性、内存空间/磁盘剩余空
间、运行时手机状态(进程所占内存、虚拟内存等)、idfv、是否越狱、地区编码
共享方式:内嵌SDK直接收集
隐私政策链接:https://privacy.qq.com/document/preview/fc748b3d96224fdb825ea79e132c1a56
SDK名称:QQ音乐开放平台SDK
第三方名称:QQ音乐
使用场景:使用QQ音乐
使用目的:提供音乐服务
个人信息种类:歌曲的歌词信息、歌手信息、歌曲时长信息、歌曲播放进度信息、歌曲播放状态信息、专辑
https://xj-platform.flyme.com/fms/policy/nocache/cf23bc5db2d95d2fae3353fdf160239f.html 第2/5⻚

## Page 3

第三方信息共享清单 2026/9/29 17:53
封面图片信息
共享方式:内嵌SDK
隐私政策链接:https://y.qq.com/m/client/intro/privacy.html
SDK名称:蜂蜜SDK
第三方名称:珠海星纪魅族信息技术有限公司
使用场景:注册、登录和使用账号
使用目的:用于Flyme账号的注册、登录和使用(含账号管理、找回密码、实名认证);用于微信第三方登
录
个人信息种类:手机号码、密码、账号、密保问题和答案、邮箱地址、注册、登录、修改设置的操作记录IP
以及时间戳、安全设置,操作系统版本,应用版本,设备唯一识别符(OAID、IDFV),二次安全验证结
果、账号昵称、头像和性别、实名认证信息(姓名、身份证号码、手机号及验证码或人脸图片);微信昵
称、微信头像和微信 openid
共享方式:内嵌SDK直接收集
隐私政策链接:
https://xj-
platform.flyme.com/fms/policy/b0e96e4f2fd92a831b30ca19bfa16f4f_ead4f669c162571295da8b5a93ce19c9_6.html
SDK名称:MSA 移动安全联盟 SDK
第三方名称:移动安全工作委员会
使用场景:根据“移动智能终端补充设备标识体系”技术要求,协助移动应用开发者更便捷的访问移动智能终
端补充设备标识体系
使用目的:判断终端品牌,调用接又、判断是否为虚拟机环境、生成VAID时判断是否为同一开发者、提供
不同移动智能终端开放匿名设备标识符(OAID)、提供不同移动智能终端开发者匿名设备标识符
(VAID)、提供不同移动智能终端应用匿名设备标识符(AAID)
个人信息种类:设备制造商、设备型号、设备品牌、设备网络运营商名称、App包名及签名信息,或在对应
应用商店的APPID、开放匿名设备标识符(OAID)、开发者匿名设备标识符(VAID)、应用匿名设备标识
符(AAID)
共享方式:内嵌SDK直接收集
隐私政策链接:http://www.msa-alliance.cn/col.jsp?id=122
SDK名称:FlymeLink SDK
第三方名称:珠海星纪魅族信息技术有限公司
使用场景:提供设备连接服务、硬件共享服务
使用目的:提供设备连接服务、已绑定设备管理功能、硬件共享服务
个人信息种类:设备信息(WIFI直连MAC地址、蓝牙MAC地址)、网络信息(网络、蓝牙开关状态、IP地
址)、附近蓝牙设备信息、蓝牙设备连接记录(设备名称、绑定时间)、终端操作系统中的Flyme ID
共享方式:内嵌SDK直接收集
隐私政策链接:https://xj-platform.flyme.com/fms/policy/nocache/f38a362a2ead58b6bd57029dfefd157d.html
SDK名称:微信Open SDK
https://xj-platform.flyme.com/fms/policy/nocache/cf23bc5db2d95d2fae3353fdf160239f.html 第3/5⻚

## Page 4

第三方信息共享清单 2026/9/29 17:53
第三方名称:深圳市腾讯计算机系统有限公司
使用场景:在运动记录页面将运动记录的数据分享给微信朋友或分享到微信朋友圈时
使用目的:进行运动数据的分享
个人信息种类:用户在本应用中主动选择的图片或内容
共享方式:客户端嵌入SDK
隐私政策链接:请查看《隐私政策》。
SDK名称:小红书Open SDK
第三方名称:行吟信息科技(上海)有限公司
使用场景:在运动记录页面将运动记录的数据分享至小红书时
使用目的:进行运动数据的分享
个人信息种类:用户在本应用中主动选择的图片或其他内容、UUDID以及设备型号和操作系统
共享方式:客户端嵌入SDK
隐私政策链接:请查看《隐私政策》。
SDK名称:微博SDK
第三方名称:北京微梦创科网络技术有限公司
使用场景:在运动记录页面将运动记录的数据分享至微博时
使用目的:进行运动数据的分享
个人信息种类:用户在本应用中主动选择的图片
共享方式:客户端嵌入SDK
隐私政策链接:请查看《隐私政策》。
2. 合作商共享信息清单
第三方名称:思必驰科技股份有限公司
使用场景:语音唤醒与语音识别
使用目的:提供语音识别服务
个人信息种类:录音数据
共享方式:服务端API传输
隐私政策链接:https://www.duiopen.com/docs/ct_ddssdkpolicy
第三方名称:上海蓝云网络科技有限公司
使用场景:使用涉及语音转写的功能时(包括语音转写、翻译官、会议助手、语音助理)
使用目的:提供语音转写为文字的服务
个人信息种类:眼镜录制的音频、配置信息(需要转写的语言,需要翻译的目标语言)
共享方式:服务端API传输
隐私政策链接:https://azure.microsoft.com/zh-cn/explore/trusted-cloud/privacy
第三方名称:通义云启(杭州)信息技术有限公司
使用场景:使用信息提炼功能、使用AI对话服务、使用DeepSeek智能体
使用目的:提供智能对话服务,包括提供智能问答、输出概要总结、待办事项
https://xj-platform.flyme.com/fms/policy/nocache/cf23bc5db2d95d2fae3353fdf160239f.html 第4/5⻚

## Page 5

第三方信息共享清单 2026/9/29 17:53
个人信息种类:用户输入信息(文本、图片)、音频转写后的文本、文件、提示语
共享方式:服务端API传输
隐私政策链接:
https://terms.alicdn.com/legal-
agreement/terms/privacy_policy_full/20231011201849846/20231011201849846.html
第三方名称:北京数美时代科技有限公司
使用场景:使用图片式生成式人工智能服务
使用目的:生成图片合规性审核
个人信息种类:文本形式的提示语、生成的图片
隐私政策链接:点击链接
第三方名称:北京墨迹风云科技股份有限公司
使用场景:用于展示天气信息
使用目的:获取天气数据
个人信息种类:位置信息
共享方式:后台接又传输
隐私政策链接:https://html5.moji.com/tpd/agreement/privacy-zh_CN.html
https://xj-platform.flyme.com/fms/policy/nocache/cf23bc5db2d95d2fae3353fdf160239f.html 第5/5⻚
