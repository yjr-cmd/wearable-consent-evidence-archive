# Huawei Health App Privacy Statement Summary

- Case: AG01
- Brand: Huawei
- Material type: Privacy statement summary
- Original filename: `华为运动健康 App 隐私声明摘要.pdf`
- Original format: PDF
- Archive role: Supporting summary associated with the Huawei Health document set.

> Note: This Markdown file is a text-access copy generated from the archived original. The original file remains the controlling archived source.

## Page 1

华为运动健康 App 隐私声明摘要 2026/9/29 17:38
华为运动健康 App 隐私声明摘要
华为(以下简称“我们”)会严格遵从国家的法律法规要求,将合法合规融入产品设计和业务流程
中,并采用业界先进的安全技术保证数据安全。同时我们非常重视您的个人信息和隐私保护,致力
于捍卫每个人的隐私权利,为此我们坚持隐私保护5个基本原则:
数据最小化:坚持仅采集实现业务功能所必须的个人数据,以服务于您的需求
数据端侧处理:坚持尽可能在用户的设备上完成个人数据的处理和分析
透明可控:当采集个人数据时,清晰、明确地告知用户,并确保用户知道数据被如何使用,以及如
何退出
身份保护:使用隐私增强技术,在数据离开用户的设备时,隐藏用户的身份
数据安全保障:坚实的数据安全是隐私保护的基础,华为围绕硬件、OS、应用及服务持续构建数据
安全能力
业 收 收
务 集 个人信 集
个人信息字段
场 目 息类型 方
景 的 式
帐号信
息、个
人基本
个
资料、
人
联系方 A
数
式、设 p 华为帐号信息、昵称、头像、性别、出生日期、联系电话、邮箱、
据
备信 p 帐号密码、帐号名、可变设备标识符(UUID)、设备信息(设备型
帐 的
息、网 收 号、设备硬件信息)、WLAN 信息(WiFi 列表)、网络信息(IP
号 存
络信 集、地址)、大致位置信息、应用设置信息、系统设置信息(国家码、
登 储
息、位 用 语言、注册地、服务地)、操作系统信息、传感器信息(陀螺
录 与
置信 户 仪)、紧急联系人姓名和联系电话、有效身份证件、应用使用信
帐
息、应 输 息、手持证件照片、人脸信息
号
用信 入
关
息、身
联
份信
息、生
物特征
帐号信
https://legal.cloud.huawei.com.cn/terms/scope/huawei/health/privacy-statement.htm?code=cn&branchid=0&language=zh-cn&contenttag=di 第1/2⻚

## Page 2

华为运动健康 App 隐私声明摘要 2026/9/29 17:38
https://legal.cloud.huawei.com.cn/terms/scope/huawei/health/privacy-statement.htm?code=cn&branchid=0&language=zh-cn&contenttag=di 第2/2⻚
