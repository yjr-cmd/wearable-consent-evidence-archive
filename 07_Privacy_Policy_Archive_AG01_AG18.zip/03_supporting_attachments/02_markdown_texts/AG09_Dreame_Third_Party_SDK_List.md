# Dreame Health Third-Party SDK List

- Case: AG09
- Brand: Dreame
- Material type: Third-party SDK information/list
- Original filename: `DreameHealth.pdf`
- Original format: PDF
- Archive role: Supporting attachment for documentary verification of third-party processing disclosures.

> Note: This Markdown file is a text-access copy generated from the archived original. The original file remains the controlling archived source.

## Page 1

DreameHealth 2026/9/29 17:52
以下为Dreame Health接入的第三方SDK信息,用于说明合作方、收集方式、信息类型、使用
目的和使用场景。
小米推送SDK
涉及的个人信息类型:
设备标识符(如Android ID、OAID)、设备信息(如设备型号、设备操作系统类型)、网
络信息、位置信息(如SSID)
使用目的:
推送消息
使用场景:
在小米手机终端推送消息时使用
合作方主体:
北京小米移动软件有限公司
收集方式:
SDK采集
官网链接:
https://dev.mi.com/console/appservice/push.html
隐私政策:
https://dev.mi.com/console/doc/detail?pId=1822
华为推送SDK
https://hub.aierdream.com/third-party-info-sharing?language=zh 第1/8⻚

## Page 2

DreameHealth 2026/9/29 17:52
涉及的个人信息类型:
应用基本信息、应用内设备标识符(如Android ID)、设备的硬件信息、系统基本信息和
系统设置信息
使用目的:
推送消息
使用场景:
在华为手机终端推送消息时使用
合作方主体:
华为软件技术有限公司
收集方式:
SDK采集
官网链接:
https://developer.huawei.com/consumer/cn/doc/app/20213
隐私政策:
https://developer.huawei.com/consumer/cn/doc/development/HMSCore-
Guides/sdk-data-security-0000001050042177
荣耀推送SDK
https://hub.aierdream.com/third-party-info-sharing?language=zh 第2/8⻚

## Page 3

DreameHealth 2026/9/29 17:52
涉及的个人信息类型:
应用匿名标识 (AAID)、应用Token、OAID
使用目的:
推送消息
使用场景:
在荣耀手机终端推送消息时使用
合作方主体:
荣耀终端有限公司
收集方式:
OPUSH SDK
SDK采集
官网链接:
涉及的个人信息类型:
https://developer.hihonor.com/cn/doc/guides/100125
设备标识符(如IMEI、ICCID、IMSI、Android ID、GAID)、应用信息(如应用包名、版
本号和运行状态)、网络信息(如IP或域名连接结果,当前网络类型)
隐私政策:
https://developer.honor.com/cn/docs/11002/guides/sdk-data-security
使用目的:
推送消息
使用场景:
在OPPO手机终端推送消息时使用
合作方主体:
广东欢太科技有限公司
收集方式:
SDK采集
官网链接:
https://open.oppomobile.com/wiki/doc#id=10194
隐私政策:
https://open.oppomobile.com/new/developmentDoc/info?id=11228
VIVO推送SDK
https://hub.aierdream.com/third-party-info-sharing?language=zh 第3/8⻚

## Page 4

DreameHealth 2026/9/29 17:52
VIVO推送SDK
涉及的个人信息类型:
设备标识信息【如IMEI(仅限安卓9以下)、EmmCID、UFSID、ANDROIDID、GUID、
GAID、OPENID、VAID、OAID、RegID、加密的Android ID】、使用推送服务的应用软
件信息(如应用包名、版本号、APPID、安装、卸载、恢复出厂设置、运行状态)、设备
制造商、网络相关信息(如IP地址、网络类型)、国家码、设备类型
使用目的:
推送消息
使用场景:
在VIVO手机终端推送消息时使用
合作方主体:
维沃移动通信有限公司
收集方式:
SDK采集
官网链接:
https://dev.vivo.com.cn/documentCenter/doc/366
隐私政策:
https://dev.vivo.com.cn/documentCenter/doc/652
极光 PUSH
https://hub.aierdream.com/third-party-info-sharing?language=zh 第4/8⻚

## Page 5

DreameHealth 2026/9/29 17:52
极光 PUSH
涉及的个人信息类型:
设备标识符(包括Android ID、GAID、OAID、UAID、AAID、IDFA、Boot ID)设备硬件
信息(包括设备型号、设备屏幕分辨率、设备硬件制造商、设备产品名称、设备存储空
间)、操作系统信息(包括操作系统版本、系统名称、系统语言)网络信息(包括网络类
型、运营商信息、IP地址、DHCP、WIFI状态信息)设备标识符(包括IMEI、MAC、
IMSI)网络信息(包括SSID、BSSID、WiFi列表信息、基站信息、SIM卡状态)
使用目的:
帮助提升推送消息触达和保障系统运行稳定
使用场景:
(本SDK仅适用于安卓手机,实际未调用)
合作方主体:
深圳市和讯华谷信息技术有限公司
收集方式:
SDK采集
官网链接:
https://www.jiguang.cn/push?
source=bdAd&plan=1&unlt=18&keyword=244&bd_vid=10960636148519080981
隐私政策:
https://www.jiguang.cn/license/privacy
https://hub.aierdream.com/third-party-info-sharing?language=zh 第5/8⻚

## Page 6

DreameHealth 2026/9/29 17:52
友盟SDK
https://hub.aierdream.com/third-party-info-sharing?language=zh 第6/8⻚

## Page 7

DreameHealth 2026/9/29 17:52
涉及的个人信息类型:
设备标识符(Android如IMEI、Android ID、ICCID、IMSI、OAID)、设备MAC地址、IP
地址、位置信息、设备信息(如设备型号、设备操作系统类型)、SSID
Sentry SDK(错误跟踪与性能监控 SDK)
使用目的:
基础统计
涉及的个人信息类型:
设备信息(如设备型号、操作系统版本、设备上下文)、随机生成的安装/会话 ID(非硬件
使用场景:
设备标识符如 Android ID)、网络信息(请求 URL、查询参数等)、IP 地址(需启用
收集用户统计相关数据
sendDefaultPii)、用户上下文(可选,如 User ID、邮箱等,需启用 PII 选项)、性能/错
合作方主体:
误事件相关数据
北京锐讯灵通科技有限公司、友盟同欣(北京)科技有限公司
使用目的:
收集方式:
错误监控、崩溃报告、性能追踪、应用稳定性分析
SDK采集
使用场景:
官网链接:
在应用运行过程中捕获异常、错误、性能问题或事务时使用
https://developer.umeng.com/docs/147377/detail/210024
合作方主体:
隐私政策:
Sentry公司
https://www.umeng.com/page/policy
收集方式:
SDK 采集
官网链接:
https://docs.sentry.io/
隐私政策:
https://sentry.io/privacy/
https://hub.aierdream.com/third-party-info-sharing?language=zh 第7/8⻚

## Page 8

DreameHealth 2026/9/29 17:52
微信开放平台 SDK
涉及的个人信息类型:
用户主动选择的分享内容(如图片、文本)(iOS 通信)、网络信息等。SDK 不会主动收
集其他未明示的个人信息。
使用目的:
实现微信分享/收藏
使用场景:
在用户进行分享、登录授权或支付操作时使用。
合作方主体:
深圳市腾讯计算机系统有限公司(腾讯)
收集方式:
SDK 采集
官网链接:
https://open.weixin.qq.com/
隐私政策:
https://support.weixin.qq.com/cgi-bin/mmsupportacctnodeweb-
bin/pages/RYiYJKLOrQwu0nb8 (《微信 Open SDK 个人信息处理规则》)
https://hub.aierdream.com/third-party-info-sharing?language=zh 第8/8⻚
